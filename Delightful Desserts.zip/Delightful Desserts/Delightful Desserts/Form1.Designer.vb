﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.RdBtnChocFudgeCake = New System.Windows.Forms.RadioButton()
        Me.RdBtnStrawberryCheesecake = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RdBtnChocIceCream = New System.Windows.Forms.RadioButton()
        Me.RdBtnVanillaIceCream = New System.Windows.Forms.RadioButton()
        Me.RdBtnStrawberryIceCream = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.RdBtnOrangeJuice = New System.Windows.Forms.RadioButton()
        Me.RdBtnFantaOrange = New System.Windows.Forms.RadioButton()
        Me.RdBtnChocolateMilkshake = New System.Windows.Forms.RadioButton()
        Me.RdBtnCoke = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.RdBtnClearForm = New System.Windows.Forms.Button()
        Me.BtnExit = New System.Windows.Forms.Button()
        Me.BtnHelp = New System.Windows.Forms.Button()
        Me.RdBtnAdditionalComment = New System.Windows.Forms.TextBox()
        Me.TxtBxTotalPrice = New System.Windows.Forms.TextBox()
        Me.RdBtnOrderButton = New System.Windows.Forms.Button()
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.TxtBxOrderSummary = New System.Windows.Forms.TextBox()
        Me.BtnTotal = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CboBxTableNumber = New System.Windows.Forms.ComboBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'RdBtnChocFudgeCake
        '
        Me.RdBtnChocFudgeCake.AutoSize = True
        Me.RdBtnChocFudgeCake.Checked = True
        Me.RdBtnChocFudgeCake.Location = New System.Drawing.Point(8, 36)
        Me.RdBtnChocFudgeCake.Name = "RdBtnChocFudgeCake"
        Me.RdBtnChocFudgeCake.Size = New System.Drawing.Size(160, 17)
        Me.RdBtnChocFudgeCake.TabIndex = 0
        Me.RdBtnChocFudgeCake.TabStop = True
        Me.RdBtnChocFudgeCake.Text = "Chocolate fudge cake £3.50"
        Me.RdBtnChocFudgeCake.UseVisualStyleBackColor = True
        '
        'RdBtnStrawberryCheesecake
        '
        Me.RdBtnStrawberryCheesecake.AutoSize = True
        Me.RdBtnStrawberryCheesecake.Location = New System.Drawing.Point(8, 86)
        Me.RdBtnStrawberryCheesecake.Name = "RdBtnStrawberryCheesecake"
        Me.RdBtnStrawberryCheesecake.Size = New System.Drawing.Size(170, 17)
        Me.RdBtnStrawberryCheesecake.TabIndex = 1
        Me.RdBtnStrawberryCheesecake.Text = "Strawberry cheese cake £3.50"
        Me.RdBtnStrawberryCheesecake.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RdBtnStrawberryCheesecake)
        Me.GroupBox1.Controls.Add(Me.RdBtnChocFudgeCake)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 146)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(181, 122)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Cakes"
        '
        'RdBtnChocIceCream
        '
        Me.RdBtnChocIceCream.AutoSize = True
        Me.RdBtnChocIceCream.Checked = True
        Me.RdBtnChocIceCream.Location = New System.Drawing.Point(34, 22)
        Me.RdBtnChocIceCream.Name = "RdBtnChocIceCream"
        Me.RdBtnChocIceCream.Size = New System.Drawing.Size(154, 17)
        Me.RdBtnChocIceCream.TabIndex = 3
        Me.RdBtnChocIceCream.TabStop = True
        Me.RdBtnChocIceCream.Text = "Chocolate Ice Cream £1.50"
        Me.RdBtnChocIceCream.UseVisualStyleBackColor = True
        '
        'RdBtnVanillaIceCream
        '
        Me.RdBtnVanillaIceCream.AutoSize = True
        Me.RdBtnVanillaIceCream.Location = New System.Drawing.Point(34, 45)
        Me.RdBtnVanillaIceCream.Name = "RdBtnVanillaIceCream"
        Me.RdBtnVanillaIceCream.Size = New System.Drawing.Size(137, 17)
        Me.RdBtnVanillaIceCream.TabIndex = 4
        Me.RdBtnVanillaIceCream.Text = "Vanilla Ice Cream £1.50"
        Me.RdBtnVanillaIceCream.UseVisualStyleBackColor = True
        '
        'RdBtnStrawberryIceCream
        '
        Me.RdBtnStrawberryIceCream.AutoSize = True
        Me.RdBtnStrawberryIceCream.Location = New System.Drawing.Point(35, 68)
        Me.RdBtnStrawberryIceCream.Name = "RdBtnStrawberryIceCream"
        Me.RdBtnStrawberryIceCream.Size = New System.Drawing.Size(156, 17)
        Me.RdBtnStrawberryIceCream.TabIndex = 5
        Me.RdBtnStrawberryIceCream.Text = "Strawberry Ice Cream £1.50"
        Me.RdBtnStrawberryIceCream.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.RdBtnStrawberryIceCream)
        Me.GroupBox2.Controls.Add(Me.RdBtnVanillaIceCream)
        Me.GroupBox2.Controls.Add(Me.RdBtnChocIceCream)
        Me.GroupBox2.Location = New System.Drawing.Point(214, 146)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(199, 121)
        Me.GroupBox2.TabIndex = 6
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Ice Cream"
        '
        'RdBtnOrangeJuice
        '
        Me.RdBtnOrangeJuice.AutoSize = True
        Me.RdBtnOrangeJuice.Checked = True
        Me.RdBtnOrangeJuice.Location = New System.Drawing.Point(12, 16)
        Me.RdBtnOrangeJuice.Name = "RdBtnOrangeJuice"
        Me.RdBtnOrangeJuice.Size = New System.Drawing.Size(118, 17)
        Me.RdBtnOrangeJuice.TabIndex = 7
        Me.RdBtnOrangeJuice.TabStop = True
        Me.RdBtnOrangeJuice.Text = "Orange Juice £2.00"
        Me.RdBtnOrangeJuice.UseVisualStyleBackColor = True
        '
        'RdBtnFantaOrange
        '
        Me.RdBtnFantaOrange.AutoSize = True
        Me.RdBtnFantaOrange.Location = New System.Drawing.Point(11, 39)
        Me.RdBtnFantaOrange.Name = "RdBtnFantaOrange"
        Me.RdBtnFantaOrange.Size = New System.Drawing.Size(120, 17)
        Me.RdBtnFantaOrange.TabIndex = 8
        Me.RdBtnFantaOrange.Text = "Fanta Orange £1.50"
        Me.RdBtnFantaOrange.UseVisualStyleBackColor = True
        '
        'RdBtnChocolateMilkshake
        '
        Me.RdBtnChocolateMilkshake.AutoSize = True
        Me.RdBtnChocolateMilkshake.Location = New System.Drawing.Point(11, 62)
        Me.RdBtnChocolateMilkshake.Name = "RdBtnChocolateMilkshake"
        Me.RdBtnChocolateMilkshake.Size = New System.Drawing.Size(154, 17)
        Me.RdBtnChocolateMilkshake.TabIndex = 9
        Me.RdBtnChocolateMilkshake.Text = "Chocolate Milkshake £3.00"
        Me.RdBtnChocolateMilkshake.UseVisualStyleBackColor = True
        '
        'RdBtnCoke
        '
        Me.RdBtnCoke.AutoSize = True
        Me.RdBtnCoke.Location = New System.Drawing.Point(11, 85)
        Me.RdBtnCoke.Name = "RdBtnCoke"
        Me.RdBtnCoke.Size = New System.Drawing.Size(80, 17)
        Me.RdBtnCoke.TabIndex = 10
        Me.RdBtnCoke.Text = "Coke £1.20"
        Me.RdBtnCoke.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.RdBtnCoke)
        Me.GroupBox3.Controls.Add(Me.RdBtnChocolateMilkshake)
        Me.GroupBox3.Controls.Add(Me.RdBtnFantaOrange)
        Me.GroupBox3.Controls.Add(Me.RdBtnOrangeJuice)
        Me.GroupBox3.Location = New System.Drawing.Point(444, 146)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(181, 120)
        Me.GroupBox3.TabIndex = 11
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Drinks"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 24)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(845, 24)
        Me.MenuStrip1.TabIndex = 12
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'RdBtnClearForm
        '
        Me.RdBtnClearForm.Location = New System.Drawing.Point(12, 407)
        Me.RdBtnClearForm.Name = "RdBtnClearForm"
        Me.RdBtnClearForm.Size = New System.Drawing.Size(128, 31)
        Me.RdBtnClearForm.TabIndex = 13
        Me.RdBtnClearForm.Text = "Clear Form "
        Me.RdBtnClearForm.UseVisualStyleBackColor = True
        '
        'BtnExit
        '
        Me.BtnExit.Location = New System.Drawing.Point(660, 407)
        Me.BtnExit.Name = "BtnExit"
        Me.BtnExit.Size = New System.Drawing.Size(128, 31)
        Me.BtnExit.TabIndex = 14
        Me.BtnExit.Text = "Exit"
        Me.BtnExit.UseVisualStyleBackColor = True
        '
        'BtnHelp
        '
        Me.BtnHelp.Location = New System.Drawing.Point(678, 115)
        Me.BtnHelp.Name = "BtnHelp"
        Me.BtnHelp.Size = New System.Drawing.Size(110, 30)
        Me.BtnHelp.TabIndex = 15
        Me.BtnHelp.Text = "Help"
        Me.BtnHelp.UseVisualStyleBackColor = True
        '
        'RdBtnAdditionalComment
        '
        Me.RdBtnAdditionalComment.Location = New System.Drawing.Point(631, 174)
        Me.RdBtnAdditionalComment.Multiline = True
        Me.RdBtnAdditionalComment.Name = "RdBtnAdditionalComment"
        Me.RdBtnAdditionalComment.Size = New System.Drawing.Size(157, 63)
        Me.RdBtnAdditionalComment.TabIndex = 16
        Me.RdBtnAdditionalComment.Text = "Additional Comment:"
        '
        'TxtBxTotalPrice
        '
        Me.TxtBxTotalPrice.Location = New System.Drawing.Point(382, 305)
        Me.TxtBxTotalPrice.Multiline = True
        Me.TxtBxTotalPrice.Name = "TxtBxTotalPrice"
        Me.TxtBxTotalPrice.Size = New System.Drawing.Size(174, 72)
        Me.TxtBxTotalPrice.TabIndex = 17
        '
        'RdBtnOrderButton
        '
        Me.RdBtnOrderButton.Location = New System.Drawing.Point(631, 243)
        Me.RdBtnOrderButton.Name = "RdBtnOrderButton"
        Me.RdBtnOrderButton.Size = New System.Drawing.Size(75, 23)
        Me.RdBtnOrderButton.TabIndex = 18
        Me.RdBtnOrderButton.Text = "Order"
        Me.RdBtnOrderButton.UseVisualStyleBackColor = True
        '
        'MenuStrip2
        '
        Me.MenuStrip2.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(845, 24)
        Me.MenuStrip2.TabIndex = 19
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'TxtBxOrderSummary
        '
        Me.TxtBxOrderSummary.Location = New System.Drawing.Point(382, 383)
        Me.TxtBxOrderSummary.Multiline = True
        Me.TxtBxOrderSummary.Name = "TxtBxOrderSummary"
        Me.TxtBxOrderSummary.Size = New System.Drawing.Size(174, 67)
        Me.TxtBxOrderSummary.TabIndex = 20
        Me.TxtBxOrderSummary.Text = "Order Summary "
        '
        'BtnTotal
        '
        Me.BtnTotal.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.BtnTotal.Location = New System.Drawing.Point(317, 305)
        Me.BtnTotal.Name = "BtnTotal"
        Me.BtnTotal.Size = New System.Drawing.Size(65, 24)
        Me.BtnTotal.TabIndex = 21
        Me.BtnTotal.Text = "Total"
        Me.BtnTotal.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label1.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Label1.Location = New System.Drawing.Point(293, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(219, 25)
        Me.Label1.TabIndex = 22
        Me.Label1.Text = "Delightful Desserts "
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'CboBxTableNumber
        '
        Me.CboBxTableNumber.FormattingEnabled = True
        Me.CboBxTableNumber.Items.AddRange(New Object() {"Table 1 ", "Table 2 ", "Table 3 ", "Table 4", "Table 5"})
        Me.CboBxTableNumber.Location = New System.Drawing.Point(7, 9)
        Me.CboBxTableNumber.Name = "CboBxTableNumber"
        Me.CboBxTableNumber.Size = New System.Drawing.Size(153, 21)
        Me.CboBxTableNumber.TabIndex = 23
        Me.CboBxTableNumber.Text = "Table Number "
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(845, 486)
        Me.Controls.Add(Me.CboBxTableNumber)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BtnTotal)
        Me.Controls.Add(Me.TxtBxOrderSummary)
        Me.Controls.Add(Me.RdBtnOrderButton)
        Me.Controls.Add(Me.TxtBxTotalPrice)
        Me.Controls.Add(Me.RdBtnAdditionalComment)
        Me.Controls.Add(Me.BtnHelp)
        Me.Controls.Add(Me.BtnExit)
        Me.Controls.Add(Me.RdBtnClearForm)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.MenuStrip2)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents RdBtnChocFudgeCake As RadioButton
    Friend WithEvents RdBtnStrawberryCheesecake As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents RdBtnChocIceCream As RadioButton
    Friend WithEvents RdBtnVanillaIceCream As RadioButton
    Friend WithEvents RdBtnStrawberryIceCream As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents RdBtnOrangeJuice As RadioButton
    Friend WithEvents RdBtnFantaOrange As RadioButton
    Friend WithEvents RdBtnChocolateMilkshake As RadioButton
    Friend WithEvents RdBtnCoke As RadioButton
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents RdBtnClearForm As Button
    Friend WithEvents BtnExit As Button
    Friend WithEvents BtnHelp As Button
    Friend WithEvents RdBtnAdditionalComment As TextBox
    Friend WithEvents TxtBxTotalPrice As TextBox
    Friend WithEvents RdBtnOrderButton As Button
    Friend WithEvents MenuStrip2 As MenuStrip
    Friend WithEvents ImageList1 As ImageList
    Friend WithEvents TxtBxOrderSummary As TextBox
    Friend WithEvents BtnTotal As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents CboBxTableNumber As ComboBox
End Class
