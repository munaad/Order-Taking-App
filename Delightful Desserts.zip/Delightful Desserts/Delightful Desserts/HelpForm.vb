﻿Public Class HelpForm
    Private Sub BtnBack_Click(sender As Object, e As EventArgs) Handles BtnBack.Click
        Me.Show()
        Form1.Show()
        Me.Hide()

    End Sub
End Class