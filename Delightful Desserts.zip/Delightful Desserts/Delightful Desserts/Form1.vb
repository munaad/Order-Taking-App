﻿Public Class Form1

    Dim orderChocFudgeCake As String
    Dim priceChocFudgeCake As Single
    Dim orderStrawberryCheesecake As String
    Dim priceStrawberryCheesecake As Single
    Dim orderChocIceCream As String
    Dim priceChocIceCream As Single
    Dim orderVanillaIceCream As String
    Dim priceVanillaIceCream As Single
    Dim orderStrawberryIceCream As String
    Dim priceStrawberryIceCream As Single
    Dim orderOrangeJuice As String
    Dim priceOrangeJuice As Single
    Dim orderFantaOrange As String
    Dim priceFantaOrange As Single
    Dim orderChocolateMilkshake As String                        'This part of the code is used to declare the items, the declared items will then be used later in the program '
    Dim priceChocolateMilkshake As Single
    Dim orderCoke As String
    Dim priceCoke As Single
    Dim MasterPassword As String = "Bobwashere"   'This code is used to create/ declare a password" 

    Dim Password As String                          'This part of the code is used to declare the password' 

    Private Sub Total_Click(sender As Object, e As EventArgs) Handles BtnTotal.Click
        If RdBtnChocFudgeCake.Checked = True Then                                  ' This code will follow all the other steps that are happening below if the radio button for the certain item is selected' 
            priceChocFudgeCake = 3.5                                               ' this code will be used to show the price of the item, this will then be used to show the final bill' 
            orderChocFudgeCake = "you have ordered a chocolate fudge cake. "       ' this will be used in order summary, it will state the item that you ordered' 

        End If
        If RdBtnStrawberryCheesecake.Checked = True Then
            priceStrawberryCheesecake = 3.5
            orderStrawberryCheesecake = "You have ordered a strawberry cheesecake. "

        End If

        If RdBtnChocIceCream.Checked = True Then
            priceChocIceCream = 1.5
            orderChocIceCream = "You have ordered chocolate ice cream. "
        End If

        If RdBtnVanillaIceCream.Checked = True Then
            priceVanillaIceCream = 1.5
            orderVanillaIceCream = "You have ordered vanilla ice cream. "
        End If

        If RdBtnStrawberryIceCream.Checked = True Then
            priceStrawberryIceCream = 1.5
            orderStrawberryIceCream = "You have ordered strawberry ice cream. "
        End If

        If RdBtnOrangeJuice.Checked = True Then
            priceOrangeJuice = 2.0
            orderOrangeJuice = "You have ordered Orange juice. "
        End If

        If RdBtnFantaOrange.Checked = True Then
            priceOrangeJuice = 1.5
            orderOrangeJuice = "You have ordered Fanta Orange Juice. "
        End If

        If RdBtnChocolateMilkshake.Checked = True Then
            priceChocolateMilkshake = 3.0
            orderChocolateMilkshake = "You have ordered chocolate milkshake. "
        End If

        If RdBtnCoke.Checked = True Then
            priceCoke = 1.2
            orderCoke = "you have ordered coke. "
        End If

        TxtBxTotalPrice.Text = Finalbill()                                             ' This part of the code is used to show the total price of what the customer has ordered, it will show the total price of what the customer has ordered
        TxtBxOrderSummary.Text = CboBxTableNumber.SelectedItem & " " & OrderSummary()  'This part of the code is used to show the total summary of what the customer has ordered, it will show every food that the customer has ordered' 

    End Sub

    Function Finalbill()
        Dim totalprice = priceChocFudgeCake + priceStrawberryCheesecake + priceChocIceCream + priceVanillaIceCream + priceStrawberryIceCream + priceOrangeJuice + priceFantaOrange + priceChocolateMilkshake + priceCoke

        Return totalprice     'This is the code for the final bill, this code will add up for the total price of what the customer has ordered, the items that were selected will be the only thing that show up in the final bill 




    End Function

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles BtnExit.Click
        Me.Close()
        ' this code will be used to close the program' 


    End Sub

    Function OrderSummary()
        Dim summary As String
        summary = orderChocFudgeCake + orderStrawberryCheesecake + orderChocIceCream + orderVanillaIceCream + orderStrawberryIceCream
        Return summary

    End Function   ' this code is for the order summary, it will show all the items that were selected in the order summary table' 

    Private Sub RdBtnClearForm_Click(sender As Object, e As EventArgs) Handles RdBtnClearForm.Click

        TxtBxOrderSummary().Text = ""
        TxtBxTotalPrice.Text = ""
        CboBxTableNumber.Text = ""

        RdBtnChocFudgeCake.Checked = False
        RdBtnStrawberryCheesecake.Checked = False
        RdBtnStrawberryIceCream.Checked = False
        RdBtnVanillaIceCream.Checked = False
        RdBtnChocIceCream.Checked = False
        RdBtnOrangeJuice.Checked = False
        RdBtnFantaOrange.Checked = False
        RdBtnChocolateMilkshake.Checked = False
        RdBtnCoke.Checked = False

        priceChocFudgeCake = 0
        orderChocFudgeCake = ""
        priceStrawberryCheesecake = 0
        orderStrawberryCheesecake = ""
        priceStrawberryIceCream = 0
        orderStrawberryIceCream = ""
        priceVanillaIceCream = 0
        orderVanillaIceCream = ""
        priceChocIceCream = 0
        orderChocIceCream = ""
        priceOrangeJuice = 0
        orderOrangeJuice = ""
        priceFantaOrange = 0
        orderFantaOrange = ""
        priceChocolateMilkshake = 0
        orderChocolateMilkshake = ""
        priceCoke = 0
        orderCoke = ""

        ' this code will be used for the clear form button, all the items that were selected alongside the final bill and order summary will be reset so that a new order can be made' 

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Do
            Password = InputBox("Please enter your password ")
            If Password <> MasterPassword Then


                MsgBox(" incorrect try again  ")


            End If



        Loop Until MasterPassword = Password

        MsgBox("login valid")



    End Sub              'this code is used for the login and password, it will show a message saying the password is incorrect if the wrong password is entered and i the right password is entered it will allow the user to enter into the program.

    Private Sub BtnHelp_Click(sender As Object, e As EventArgs) Handles BtnHelp.Click
        Me.Hide()
        HelpForm.Show()





    End Sub

End Class